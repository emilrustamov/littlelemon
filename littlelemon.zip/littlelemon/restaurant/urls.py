from django.urls import path
from .views import booking_view
from .views import bookings_api

urlpatterns = [
    path('booking/', booking_view, name='booking'),
    path('bookings/', bookings_api, name='bookings_api'),
]

